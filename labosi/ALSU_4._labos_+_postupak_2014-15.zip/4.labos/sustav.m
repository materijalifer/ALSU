function F=sustav(x,H,D,Kp,hc)

%udaljenost^2 do podno�ja �ovjeka
ud=H^2+D^2;

%udaljenost^2 do vrha �ovjeka
ug=(H-hc)^2+D^2;

%x[beta, gama, fi]
F=[2*Kp*sin(x(1)/2)*cos(x(1)/2-x(2))-sin(x(2));
    ug+ud-hc^2-2*sqrt(ug)*sqrt(ud)*cos(x(2));
    tan(x(3)-x(1)/2)-(H-hc)/D];
