f=2.8;
D=8;
H=3;
fi=35.6*pi/180; %radijani
hc=1;
s=1/3;

if s == 1/4''
    a = 3.6;
    b = 2.7;
    elseif s == 1/3''
        a = 4.8;
        b = 3.6;   
    elseif s == 1/2''
        a = 6.4;
        b = 4.8;
    elseif s == 2/3''
        a = 8.8;
        b = 6.6;
    else error('pogreska pri unosu tipa senzora');
end
  
beta=2*atan(b/(2*f));

%udaljenost do glave
ug = sqrt((H-hc)^2+D^2);

%epsilom
epsilon=fi-atan((H-hc)/D);
 
%visina na M
visina = ug*cos(epsilon);

%sigma
sigma=atan(H/D)-fi;
 
%racunanje M-a
 M1=visina*tan(sigma);
 M2=ug*sin(epsilon);
 M=M1+M2;
 
%Racunanje A
 A=2*visina*tan(beta/2);

 %omjer
 Kp=M/A