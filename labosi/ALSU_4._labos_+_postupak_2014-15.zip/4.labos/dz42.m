D=5;
H=3;
hc=1.8;
s=1/3;
Kp=1.2;
hmin=0;

if s == 1/4''
    a = 3.6;
    b = 2.7;
    elseif s == 1/3''
        a = 4.8;
        b = 3.6;   
    elseif s == 1/2''
        a = 6.4;
        b = 4.8;
    elseif s==2/3''
        a = 8.8;
        b=6.6;
    else error('pogreska pri unosu tipa senzora');
end


%x[beta, gama, fi]
x0=[0 0 0];
[x,fval]=fsolve(@(x)sustav(x,H,D,Kp,hc),x0);

%ra�unanje �ari�ne duljine f
f=b/(2*tan(x(1)/2))

%nagib kamere prema horizontali fi
fi=radtodeg(x(3))

%ra�unanje kuta alfa
alfa=2*atan(a/(2*f));

%ra�unanje delte
delta=2*atan(tan(alfa/2)*cos(x(1)/2));

%ra�unanje �irine W
W=2*sqrt(D^2+(H-hc)^2)*tan(delta/2)
% W=vpa(W,3)


